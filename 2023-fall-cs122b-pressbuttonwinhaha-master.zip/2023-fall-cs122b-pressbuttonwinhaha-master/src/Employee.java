public class Employee {

    private final String email;

    public Employee(String email) {
        this.email = email;
    }
}
