
public class RecaptchaConstants {
    public static final String SECRET_KEY = "6LeDJeYoAAAAALr-5aGdpN95GAegWT7Qgo75TFO0";
}
